<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/approval_assign.php';

	$database = new Database();
	$db = $database->getConnection();

	$approval_assign = new ApprovalAssign($db);
	$data = json_decode(file_get_contents("php://input"));

	$i = 0;
	foreach ($data->approval_assign_detail as $detail) {

		$approval_assign->process = $detail->process;
		$approval_assign->staff_id = $detail->staff_id;
		$approval_assign->approval_staff_id = $detail->approval_staff_id;
		$approval_assign->permission_edit = $detail->permission_edit;
		$approval_assign->order_no = $detail->order_no;
		$approval_assign->condition = $detail->condition;

		if($i==0) $approval_assign->delete();

		if(!$approval_assign->create()){
			$arr = array(
				"message" => "error"
			);
			echo json_encode($arr);
			die();
		}
		++$i;
	}
	$arr = array(
		"message" => "created"
	);
	echo json_encode($arr);
?>