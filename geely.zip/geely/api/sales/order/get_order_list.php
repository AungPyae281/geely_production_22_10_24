<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/order.php';
    include_once '../../objects/approval.php';

    session_start();
    date_default_timezone_set('Asia/Rangoon');  

    $database = new Database();
    $db = $database->getConnection();

    $order = new Order($db);
    $approval = new Approval($db);

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['staff_id']!=""){

        $order->staff_id = $_SESSION['staff_id'];
        $order->position = $_SESSION['position'];

        $order->process = "Confirm Order"; 

        $stmt = $order->getOrderList();
        $num = $stmt->rowCount(); 

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row); 
                $approval_flow = ""; 
                $order_process = "";
                $sign = 0;
                $cancel = 0;

                $approval->process = "Confirm Order";
                $approval->main_id = $oc_no; 

                $stmt1 = $approval->getApprovalList();
                $num1 = $stmt1->rowCount();
                if($num1>0){
                    while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
                        extract($row1);
                        if($status=="Approve"){
                            $color = "#13c613";
                        }else if($status=="Reject"){
                            $color = "#e40d0d";
                        }else{
                            $color = "#bebebe";
                        } 
                        $approval_flow = $approval_flow . (($approval_flow!="")?"<br>":"") . $order_no . ') ' . '<i class="fa fa-circle" style="color:' . $color . '"></i> ' . $role;
                    }
                }

                if($approve_left<=0){
                    $order_process = "Signature";
                    $sign = 1;
                }else if($approve_left==3){
                    $order_process = "Confirm Order";
                    $cancel = 1;
                }else{
                    $order_process = "Confirm Order";
                }


                $detail = array(    
                    $date . substr($entry_date_time, 10, 6),
                    $oc_no,
                    '<span data-id="' . $staff_id . '"></span>' . $staff_name,
                    $name,
                    $vin_no,
                    $sales_type,
                    number_format($selling_price), 
                    $order_process,
                    $approval_flow,    
                    $customer_id . "|" . $sign . "|" . $cancel
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>