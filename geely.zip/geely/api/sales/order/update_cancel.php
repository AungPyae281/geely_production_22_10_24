<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/order.php';
	include_once '../../objects/car_stock.php';
	include_once '../../objects/approval.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$order = new Order($db);
	$car_stock = new CarStock($db);
	$approval = new Approval($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){
		$order->oc_no = $data->oc_no;
		if($order->testCancel()){
				$car_stock->oc_no = $data->oc_no;
				$car_stock->vin_no = $data->vin_no;
				$car_stock->engine_no = $data->engine_no;
				$car_stock->updateOrderCancel();

				$approval->main_id = $data->oc_no;
				$approval->process = "Order Cancel";
				$approval->staff_id = $_SESSION["staff_id"];
				$approval->order_no = $data->order_no;
				$approval->approve_date_time = date("Y-m-d H:i:s");
				$approval->updateCancelApproval();
			$arr = array( 
				"message" => "updated"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>	