<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sales.php';
	include_once '../../objects/car_stock.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$sales = new Sales($db);
	$car_stock = new CarStock($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){

		$sales->oc_no = $data->oc_no;
		$sales->vin_no = $data->vin_no;
		$sales->engine_no = $data->engine_no;

		$car_stock->oc_no = $data->oc_no;
		$car_stock->sales_id = $data->sales_id;
		$car_stock->vin_no = $data->vin_no;
		$car_stock->engine_no = $data->engine_no;

		if($sales->updateVNAssign()){
			if(!$car_stock->updateVNAssign()){
				$arr = array(
					"message" => "errorCarStock"
				);
				echo json_encode($arr);
				die();
			}
		}else{
			$arr = array(
				"message" => "error"
			);
			echo json_encode($arr);
			die();
		}
			
		$arr = array(
			"message" => "updated"
		);
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>