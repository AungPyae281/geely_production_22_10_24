<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	  
	include_once '../../config/database.php';
	include_once '../../objects/car_list.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	
	$car_list = new CarList($db);
	$data = json_decode(file_get_contents("php://input"));

	$arr = array();
	$arr["modelYear"] = array();
	$arr["grades"] = array();
	$arr["colors"] = array();

	$stmt1 = $car_list->getAllModelYear();
	$num1 = $stmt1->rowCount();

	if($num1>0){	
		while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
			extract($row1);
			$detail = array(
				"model" => $model,
				"year" => $year,
				"model_year" => $model_year
			);
			array_push($arr["modelYear"], $detail);
		}	
	}

	$stmt2 = $car_list->getAllGrades();
	$num2 = $stmt2->rowCount();

	if($num2>0){	
		while ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)){
			extract($row2);
			$detail = array(
				"model" => $model,
				"year" => $year,
				"model_year" => $model_year,
				"grade" => $grade
			);
			array_push($arr["grades"], $detail);
		}	
	}

	$stmt3 = $car_list->getAllColors();
	$num3 = $stmt3->rowCount();

	if($num3>0){	
		while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
			extract($row3);
			$arrColor = explode("|", $exterior_color);
			foreach ($arrColor as $c) {
				$detail = array(
					"model" => $model,
					"year" => $year,
					"model_year" => $model_year,
					"grade" => $grade,
					"color" => $c
				);
				array_push($arr["colors"], $detail);
			}
		}	
	}
	echo json_encode($arr);
?>