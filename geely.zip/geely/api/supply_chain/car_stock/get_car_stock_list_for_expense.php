<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/car_stock.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $car_stock = new CarStock($db);   

    $stmt = $car_stock->getAllCarStockForExpenseDTG();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array(); 

    $i=0;

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                ++$i,
                $brand,
                $model,
                $model_year,
                $grade,
                $engine_power,
                $interior_color,
                $exterior_color,
                $vin_no,
                $engine_no,
                $stock_status,
                $location,
                $id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>