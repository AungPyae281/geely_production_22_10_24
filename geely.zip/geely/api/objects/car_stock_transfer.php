<?php
class CarStockTransfer{
	// database connection and table name
	private $conn;
	private $table_name = "car_stock_transfer";

	// object properties 
	public $id;
	public $car_stock_id;
	public $from;
	public $to;
	public $transfer_date;
	public $transfer_time;
	public $arrival_date;
	public $arrival_time;
	public $departure_mileage;
	public $departure_fuel_level;
	public $arrival_mileage;
	public $arrival_fuel_level;
	public $transporter;
	public $transfer_reason;
	public $driver_id;
	public $t_name;
	public $t_phone;
	public $inspection_in;
	public $inspection_out;
	public $entry_by;
	public $entry_date_time; 

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET car_stock_id=:car_stock_id, `from`=:from, `to`=:to, transfer_date=:transfer_date, transfer_time=:transfer_time, arrival_date=:arrival_date, arrival_time=:arrival_time, transporter=:transporter, departure_mileage=:departure_mileage, departure_fuel_level=:departure_fuel_level, arrival_mileage=:arrival_mileage, arrival_fuel_level=:arrival_fuel_level, transfer_reason=:transfer_reason, driver_id=:driver_id, t_name=:t_name, t_phone=:t_phone, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":car_stock_id", $this->car_stock_id);
		$stmt->bindParam(":from", $this->from);
		$stmt->bindParam(":to", $this->to);
		$stmt->bindParam(":transfer_date", $this->transfer_date);
		$stmt->bindParam(":transfer_time", $this->transfer_time);
		$stmt->bindParam(":arrival_date", $this->arrival_date);
		$stmt->bindParam(":arrival_time", $this->arrival_time);
		$stmt->bindParam(":transporter", $this->transporter);
		$stmt->bindParam(":departure_mileage", $this->departure_mileage);
		$stmt->bindParam(":departure_fuel_level", $this->departure_fuel_level);
		$stmt->bindParam(":arrival_mileage", $this->arrival_mileage);
		$stmt->bindParam(":arrival_fuel_level", $this->arrival_fuel_level);
		$stmt->bindParam(":transfer_reason", $this->transfer_reason);
		$stmt->bindParam(":driver_id", $this->driver_id);
		$stmt->bindParam(":t_name", $this->t_name);
		$stmt->bindParam(":t_phone", $this->t_phone);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function updateFileName(){
		$query = "UPDATE `" . $this->table_name . "` SET 
		 inspection_in=:inspection_in
		,inspection_out=:inspection_out WHERE id=:id";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":inspection_in", $this->inspection_in);
		$stmt->bindParam(":inspection_out", $this->inspection_out);

		if($stmt->execute()){
			return true;
		}
		return false;
    }
}
?>