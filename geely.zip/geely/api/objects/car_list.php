<?php
class CarList{
    // database connection and table name
	private $conn;
	private $table_name = "car_list";

	// object properties 
	public $id;
	public $brand;
	public $model;
	public $model_year;
	public $grade_id;
	public $grade;
	public $engine_power;
	public $interior_color;
	public $exterior_color;
	public $vehicle_price;
	public $json_id;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$condition = "";
		if($this->id){
			$condition .= " AND id<>:id ";
		}
		$query = "SELECT id FROM " . $this->table_name . " WHERE `brand`=:brand AND `model`=:model AND `model_year`=:model_year AND `grade`=:grade AND `engine_power`=:engine_power AND `interior_color`=:interior_color AND `exterior_color`=:exterior_color " . $condition . " LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );

		$this->brand = htmlspecialchars(strip_tags($this->brand));
		$this->model = htmlspecialchars(strip_tags($this->model));
		$this->model_year = htmlspecialchars(strip_tags($this->model_year));
		$this->grade = htmlspecialchars(strip_tags($this->grade));
		$this->engine_power = htmlspecialchars(strip_tags($this->engine_power));
		$this->interior_color = htmlspecialchars(strip_tags($this->interior_color));
		$this->exterior_color = htmlspecialchars(strip_tags($this->exterior_color));

		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":interior_color", $this->interior_color);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		if($this->id) $stmt->bindParam(":id", $this->id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `brand`=:brand, `model`=:model, `model_year`=:model_year, `grade_id`=:grade_id, `grade`=:grade, `engine_power`=:engine_power, `interior_color`=:interior_color, `exterior_color`=:exterior_color";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":grade_id", $this->grade_id);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":interior_color", $this->interior_color);
		$stmt->bindParam(":exterior_color", $this->exterior_color);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}

	function update(){
		$query = " UPDATE " . $this->table_name . " SET `brand`=:brand, `model`=:model, `model_year`=:model_year, `grade_id`=:grade_id, `grade`=:grade, `engine_power`=:engine_power, `interior_color`=:interior_color, `exterior_color`=:exterior_color WHERE id=:id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":grade_id", $this->grade_id);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":interior_color", $this->interior_color);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

	function getAllCarListByBMYG(){
		$condition = "";	

		if($this->brand){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " brand =:brand ";
		}
		if($this->model){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `model` =:model ";
		}
		if($this->model_year){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `model_year` =:model_year ";
		}

		if($this->grade){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `grade` =:grade ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY brand, model, `model_year`, grade";
		$stmt = $this->conn->prepare($query);

		if($this->brand) $this->brand = htmlspecialchars(strip_tags($this->brand));
		if($this->model) $this->model = htmlspecialchars(strip_tags($this->model));
		if($this->model_year) $this->model_year = htmlspecialchars(strip_tags($this->model_year));
		if($this->grade) $this->grade = htmlspecialchars(strip_tags($this->grade));
		
		if($this->brand) $stmt->bindParam(":brand", $this->brand);
		if($this->model) $stmt->bindParam(":model", $this->model);
		if($this->model_year) $stmt->bindParam(":model_year", $this->model_year);
		if($this->grade) $stmt->bindParam(":grade", $this->grade);
		
		$stmt->execute();
		return $stmt;
	}

	function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE id=:id LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->brand = $row['brand'];
			$this->model = $row['model'];
			$this->model_year = $row['model_year'];
			$this->grade = $row['grade'];
			$this->grade_id = $row['grade_id'];
			$this->engine_power = $row['engine_power'];
			$this->interior_color = $row['interior_color'];
			$this->exterior_color = $row['exterior_color'];
			return true;
		}
		return false;
	}

	function getAllCarList(){
		$query = "SELECT car_list.*, IFNULL(stock_qty, 0) AS stock_qty FROM car_list LEFT JOIN (SELECT car_list_id, COUNT(id) AS stock_qty FROM car_stock WHERE oc_no='' GROUP BY car_list_id) AS cs ON car_list.id = cs.car_list_id ORDER BY brand, model, model_year, grade";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function getAllCarListForPriceChange(){
		$condition = "";	

		if($this->brand){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " car_list.brand =:brand ";
		}

		if($this->model){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " car_list.`model` =:model ";
		}

		if($this->model_year){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " car_list.`model_year` =:model_year ";
		}

		if($this->grade){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " car_list.`grade` =:grade ";
		}

		if($this->interior_color){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " car_list.`interior_color` =:interior_color ";
		}

		if($this->exterior_color){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " car_list.`exterior_color` =:exterior_color ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT car_list.*, IFNULL(cpc.vehicle_price, 0) AS vehicle_price, IFNULL(rtad_tax, 0) AS rtad_tax FROM " . $this->table_name . " LEFT JOIN grade ON car_list.grade_id=grade.id LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id " . $condition . " ORDER BY brand, model, model_year, grade, interior_color, exterior_color";

		$stmt = $this->conn->prepare($query);
		
		if($this->brand) $this->brand=htmlspecialchars(strip_tags($this->brand));
		if($this->model) $this->model=htmlspecialchars(strip_tags($this->model));
		if($this->model_year) $this->model_year=htmlspecialchars(strip_tags($this->model_year));
		if($this->grade) $this->grade=htmlspecialchars(strip_tags($this->grade));
		if($this->interior_color) $this->interior_color=htmlspecialchars(strip_tags($this->interior_color));
		if($this->exterior_color) $this->exterior_color=htmlspecialchars(strip_tags($this->exterior_color));
		
		if($this->brand) $stmt->bindParam(":brand", $this->brand);
		if($this->model) $stmt->bindParam(":model", $this->model);
		if($this->model_year) $stmt->bindParam(":model_year", $this->model_year);
		if($this->grade) $stmt->bindParam(":grade", $this->grade);
		if($this->interior_color) $stmt->bindParam(":interior_color", $this->interior_color);
		if($this->exterior_color) $stmt->bindParam(":exterior_color", $this->exterior_color);
		
		$stmt->execute();
		return $stmt;
	} 
 
	function getAllModelYear(){
		$query = "SELECT model, model_year AS `year`, CONCAT(`model`, ' - ', model_year) AS model_year FROM " . $this->table_name . " GROUP BY model, model_year ORDER BY model, model_year";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllGrades(){
		$query = "SELECT model, model_year AS `year`, CONCAT(`model`, ' - ', model_year) AS model_year, grade FROM " . $this->table_name . " GROUP BY model, model_year, grade ORDER BY model, model_year, grade";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllColors(){
		$query = "SELECT model, model_year AS `year`, CONCAT(`model`, ' - ', model_year) AS model_year, grade, exterior_color FROM " . $this->table_name . " GROUP BY model, model_year, grade, exterior_color ORDER BY model, model_year, grade, exterior_color";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllBrandsByOC(){
		$query = "SELECT brand FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY brand ORDER BY brand";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllModelsByOC(){
		$query = "SELECT brand, model FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY brand, model ORDER BY brand, model";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllModelYearsByOC(){
		$query = "SELECT brand, model, model_year FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY brand, model, model_year ORDER BY brand, model, model_year";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllGradesByOC(){
		$query = "SELECT brand, model, model_year, grade FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY brand, model, model_year, grade ORDER BY brand, model, model_year, grade";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllExteriorColorsByOC(){
		$query = "SELECT brand, model, model_year, grade, exterior_color FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY brand, model, model_year, grade, exterior_color ORDER BY brand, model, model_year, grade, exterior_color";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllInteriorColorsByOC(){
		$query = "SELECT brand, model, model_year, grade, exterior_color, interior_color FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY brand, model, model_year, grade, exterior_color, interior_color ORDER BY brand, model, model_year, grade, exterior_color, interior_color";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	} 

	function getAllPricesByOC(){
		$query = "SELECT car_list.brand, car_list.model, car_list.model_year, car_list.grade, car_list.exterior_color, car_list.interior_color, IFNULL(cpc.vehicle_price, 0) AS vehicle_price, IFNULL(rtad_tax, 0) AS rtad_tax FROM car_list LEFT JOIN grade ON car_list.grade_id=grade.id LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_list.id=cpc.car_list_id WHERE IFNULL(cpc.vehicle_price, 0)<>0 GROUP BY car_list.brand, car_list.model, car_list.model_year, car_list.grade, car_list.grade, car_list.exterior_color, car_list.interior_color ORDER BY car_list.brand, car_list.model, car_list.model_year, car_list.grade, car_list.grade, car_list.exterior_color, car_list.interior_color";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}  

	function getCarListID(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE brand=:brand AND model=:model AND model_year=:model_year AND grade=:grade AND exterior_color=:exterior_color AND interior_color=:interior_color LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		$stmt->bindParam(":interior_color", $this->interior_color);

		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return (int)$row['id'];
		}
		return 0;
	}

	// function getAllGradeList(){
	// 	$condition = "";	

	// 	if($this->brand){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " `brand` = :brand ";
	// 	}
	// 	if($this->model){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " `model` = :model ";
	// 	}
	// 	if($this->model_year){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " `model_year` = :model_year ";
	// 	}

	// 	if($this->grade){
	// 		if($condition!=""){
	// 			$condition .= " AND ";
	// 		}
	// 		$condition .= " `grade` = :grade ";
	// 	}
		
	// 	if($condition!=""){
	// 		$condition = " WHERE " . $condition;
	// 	}

	// 	$query = "SELECT grade.*, `brand`, `model`, `model_year` FROM " . $this->table_name . " LEFT JOIN model ON grade.model_id=model.id " . $condition . " ORDER BY grade, `model_year`";

	// 	$stmt = $this->conn->prepare($query);
		
	// 	if($this->brand) $this->brand=htmlspecialchars(strip_tags($this->brand));
	// 	if($this->model) $this->model=htmlspecialchars(strip_tags($this->model));
	// 	if($this->model_year) $this->model_year=htmlspecialchars(strip_tags($this->model_year));
	// 	if($this->grade) $this->grade=htmlspecialchars(strip_tags($this->grade));
		
	// 	if($this->brand) $stmt->bindParam(":brand", $this->brand);
	// 	if($this->model) $stmt->bindParam(":model", $this->model);
	// 	if($this->model_year) $stmt->bindParam(":model_year", $this->model_year);
	// 	if($this->grade) $stmt->bindParam(":grade", $this->grade);
		
	// 	$stmt->execute();
	// 	return $stmt;
	// }   
}
?>