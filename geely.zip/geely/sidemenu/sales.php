<style>
    .brand-link .brand-image-xs{
        margin-top: -0.4rem !important;
        max-height: 45px !important;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link{
        background-color: #1b8cc5;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:focus, [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:hover {
        background-color: #10649c !important;
        color: #fff;
    }  
    [class*='sidebar-dark-'] .nav-treeview > .nav-item > .nav-link.activeMenu{
        background-color: #10649c !important;
    }  
    .activee {
        color: #fff !important;
        background-color: #10649c !important;
    }

    .activeMenu {
      background-color: #10649c  !important;
      color: #fff !important;
    } 
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link" style="height: 56px;">
        <img src="<?=$app_url;?>img/logo_sm.png" alt="Geely Logo Small" class="brand-image-xl logo-xs">
        <img src="<?=$app_url;?>img/logo.png" alt="Geely Logo Large" class="brand-image-xs logo-xl" style="left: 54px;">
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image"> 
                <img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info" style="padding-top: 0px;">
                <p style="margin-bottom: 0px;color: #006b79;"><?=$_SESSION['user'];?></p>
                <a href="#"><?=$_SESSION['userrole'];?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?=$app_url;?>index.<?=$_SESSION['dashboard'];?>.php" class="nav-link">
                        <i class="nav-icon fa fa-home fa-fw"></i> <p>Home</p>
                    </a>
                </li>
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-plus-circle"></i>
                        <p>Entry <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/brand.php" data="Brand|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Brand</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/model.php" data="Model|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Model</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/grade.php" data="New Model|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Grade</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/car_list.php" data="Car List|111000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Car List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/production_order.php" data="Production Order|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Production Order</p>
                            </a>
                        </li>
                    </ul>
                </li> 
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-cog"></i>
                        <p>Setup <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sales/showroom_assign.php" data="Showroom Assign|110100" data-key class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Showroom Assign</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sales/se_assign.php" data="SE Assign|110100" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>SE Assign</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>payment_config/promotion.php" data="Promotion|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Promotion</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sales/broker.php" data="Broker|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Broker</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/test_drive_car.php" data="Test Drive Car|110100" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Test Drive Car</p>
                            </a>
                        </li>
                    </ul>
                </li> 

                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/customer_list.php" data="Customer Detail|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-address-book nav-icon"></i>
                        <p>Leads List</p>
                    </a>
                </li>
                 <li class="nav-item">
                    <a href="<?=$app_url;?>test_drive/test_drive_booking_list.php" data="Test Drive Booking List|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Test Drive Booking List</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?=$app_url;?>test_drive/test_drive_result_list.php" data="Test Drive Result List|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Test Drive Result List</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/order_processing_list.php" data="Order Detail|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Order Processing List</p>
                    </a>
                </li> 
                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/order_cancellation_list.php" data="Order Cancel Detail|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Order Cancellation List</p>
                    </a>
                </li> 
                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/sales_list.php" data="1. Sales List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Sales Processing List</p>
                    </a>
                </li>

                 <li class="nav-item">
                    <a href="<?=$app_url;?>sales/expense_request_form.php" data="Expense Request Form|100000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Expense Request Form</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/requisition_list.php" data="Requisition List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-file-invoice nav-icon"></i>
                        <p>Requisition List</p>
                    </a>
                </li>
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-truck"></i>
                        <p>Inventory <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/car_stock.php" data="Car Stock|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Stock In</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-chart-bar"></i> <p>Reports <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/customer_s.php" data="Customer Report|010010" data-key class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Customer</p>
                                </a>
                                <a href="<?=$app_url;?>reports/order_s.php" data="Order Report|010010" data-key class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Order</p>
                                </a>
                                <a href="<?=$app_url;?>reports/sales_s.php" data="Sales Report|010010" data-key class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Sales</p>
                                </a>
                                <a href="<?=$app_url;?>reports/car_stock.php" data="Car Stock Report|010010" data-key class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Car Stock</p>
                                </a>
                            </li>
                        </li>
                    </ul>
                </li>

            </ul>
        </nav>
    </div>
</aside>     