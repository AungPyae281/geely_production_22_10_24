<?php include '../header.php'; ?>  

<style>
	#myTable tbody td{
		vertical-align: top;
	}	
	.align{
		text-align: right;
	}
</style>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid"></div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                	<div class="card card-outline card-primary">
                		<div class="card-header">
							<h3 class="card-title">Order Processing List</h3>
							<div class="card-tools">
								<div><i class="fa fa-circle" style="color:#bebebe"></i> Pending &nbsp; <i class="fa fa-circle" style="color:#13c613"></i> Approve &nbsp; <i class="fa fa-circle" style="color:#e40d0d"></i> Reject</div>
							</div>
						</div>
						<div class="overlay white" id="loading" style="display: none; position: absolute; width: 100%; height: 100%; z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<div class="card-body">
							<table id="myTable" class="display nowrap">
								<thead>
									<tr>
										<th>Date/Time</th>
										<th>O.C No.</th>
										<th>Sales Executive</th>
										<th>Customer Name</th> 
										<th>Particular</th>
										<th>Sales Type</th>
                                        <th>RRP</th>  
                                        <th>Process</th>
										<th>Approval Flow</th>	
										<th>Action</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
                	</div>
                </div>	
            </div>
        </div>
    </section>
</div>
<?php include '../footer.php'; ?>
<script>	
	$(function() {
		$("body").addClass("sidebar-collapse");
		fillGrid();
	});	

	function fillGrid(){
		table = $('#myTable').DataTable({
			"scrollX": true,
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"order": [[ 0, "desc" ]],
			'columnDefs': [	
				{
					'targets': 9,
					'searchable': false,
					'orderable': false,
					'render': function (data){	 
						var dataVal = data.split("|");
						var btn = "";
						btn = '<button type="button" class="btn btn-primary btn-sm" onclick="goToDetail(\'' + dataVal[0] + '\', this);" style="min-width: 44px;">Detail</button>';
						if(parseInt(dataVal[1])==1){
							btn += ' <button type="button" class="btn btn-primary btn-sm" onclick="goToOCSignature(this);" style="min-width: 44px;">Signature</button>';
						}
						if(parseInt(dataVal[2])==1){
							btn += ' <button type="button" class="btn btn-danger btn-sm" onclick="goToCancelOrder(this);" style="min-width: 44px;">Cancel Order</button>';
						}

						return '<td>' + btn + '</td>';	
					}
				},
				{
					'targets': [6, 8],
					'searchable': false
				},
                { 
                    'targets': [6], 
                    'className': "align" 
                }
			],
			"ajax": APP_URL + "api/sales/order/get_order_list.php"
		});		
	}	

	function goToDetail(cid, obj){
		document.location = APP_URL + "sales/order_edit.php?act=edit&oc_no=" + $(obj).parent().parent().find("td").eq(1).text();
	}

	function goToOCSignature(obj){
		document.location = APP_URL + "sales/order_confirmation.php?act=entry&oc_no=" + $(obj).parent().parent().find("td").eq(1).text();
	}

	function goToCancelOrder(obj){
		document.location = APP_URL + "sales/order_edit.php?act=cancel&oc_no=" + $(obj).parent().parent().find("td").eq(1).text();
	}
</script>