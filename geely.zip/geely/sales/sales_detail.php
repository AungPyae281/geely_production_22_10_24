<?php include '../header.php'; ?>
<?php
$oc_no = "";
if(isset($_GET['oc_no'])){
	if(!empty($_GET['oc_no'])){
		$oc_no = $_GET['oc_no'];
	}
}
?> 
<style>
	label{
		padding-top: 3px !important;
		padding-left: 0px !important;
		padding-right: 0px !important;
	}
	.input-group-addon{
		height: 36px !important;
	}
	#toggleStatus .active{
		background-color: #0062cc;
		border-color: #0062cc;
		color: #ffffff;
	}
	#toggleStatus .btn-group-toggle>label:hover{
		background-color: #0062cce3;
		border-color: #0062cce3;
		color: #ffffff;
	}
	#toggleStatus .btn-group-toggle>label{
		cursor: not-allowed !important;
		min-width: 100px;
		padding-top: 8px !important;
		padding-left: 8px !important;
		padding-right: 8px !important;
	}
	#toggleStatus .toggle{
		min-height: 31px !important;
	}
	.checkbox-inline {
		padding-top: 1px !important;
		margin-bottom: 0px !important;
	}
	.checkbox-inline .toggle{
		margin-left: 0px !important;
		width: 75px !important;
	}
	.toggle-on, .toggle-off{
		line-height: 25px !important;
		cursor: not-allowed !important;
	}
	.previewing{
		width: 100%;
		height: 135px;
		cursor: pointer; 
		object-fit: cover;
	}
	.displayNone{
		display: none;
	}
	.toggle{
		min-width: 100px !important;
	}
	.checkbox{
		float: right;
	}
	select{
		padding-top: 2px !important;
	}
</style> 
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Sales Detail</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title" style="font-weight: bold;" id="txtOCNo"></h3>
						</div> 
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row" style="padding-top: 9px;">
									<div class="col-md-12">
										<div class="card card-outline card-outline-tabs">
											<div class="card-header p-0 border-bottom-0">
												<ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
													<li class="nav-item">
														<a class="nav-link active" id="custom-tabs-four-customer-tab" data-toggle="pill" href="#custom-tabs-four-customer" role="tab" aria-controls="custom-tabs-four-customer" aria-selected="true">Customer Info</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-four-rtad-tab" data-toggle="pill" href="#custom-tabs-four-rtad" role="tab" aria-controls="custom-tabs-four-rtad" aria-selected="false">RTAD Register Info</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-four-vehicle-tab" data-toggle="pill" href="#custom-tabs-four-vehicle" role="tab" aria-controls="custom-tabs-four-vehicle" aria-selected="false">Vehicle Info</a>
													</li>
												</ul>
											</div>
											<div class="card-body">
												<div class="tab-content" id="custom-tabs-four-tabContent">
													<div class="tab-pane fade active show" id="custom-tabs-four-customer" role="tabpanel" aria-labelledby="custom-tabs-four-customer-tab">
														<div class="row brokerInfoPanel" style="display: none;">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Broker Registration No.: </label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtBrokerRegistrationNo" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Broker Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtBrokerName" disabled>
																	</div>
																</div>
															</div>
														</div>
														<hr class="brokerInfoPanel" style="display: none;">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerRegistrationNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerName" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Type:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerType" disabled>
																	</div>
																</div>
																<div class="form-group row b2bPanel" style="display: none;">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Company Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCompanyName" disabled>
																	</div>
																</div>
																<div class="form-group row b2bPanel" style="display: none;">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Company Register No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCompanyRegisterNo" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Email:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerEmail" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerTownship" disabled>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-four-rtad" role="tabpanel" aria-labelledby="custom-tabs-four-rtad-tab">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Same as Buyer:</label>
																	<div class="col-md-8">
																		<div class="input-group mb-3" style="margin-bottom: 0px !important;">
																			<div class="checkbox">
																				<label class="checkbox-inline" style="padding-left: 20px;cursor: not-allowed;" >
																					<input type="checkbox" data-toggle="toggle" id="chkSameAsBuyer" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="default" class="ssToggle" checked disabled>
																				</label>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADName" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADNRCNo" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADMobileNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADTownship" disabled>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-four-vehicle" role="tabpanel" aria-labelledby="custom-tabs-four-vehicle-tab">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Brand:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtBrand" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Model:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtModel" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Model Year:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtModelYear" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Grade:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtGrade" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Exterior Color:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtExteriorColor" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Interior Color:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtInteriorColor" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtVinNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtEngineNo" disabled>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<!-- Calculation -->
								<div class="row" style="padding-top: 12px;padding-right: 19px;padding-left: 19px;">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Sales Date:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtSalesDate" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtSalesCenter" disabled>
											</div>	
										</div>
										<div class="form-group row promotionPanel" style="display: none;">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Code:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionCode" disabled>
											</div>	
										</div>
										<div class="form-group row depositPanel" style="display: none;">
											<label class="col-md-4 col-form-label" style="text-align: right;">Deposit:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtDeposit" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Type:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPaymentType" disabled>
											</div>
										</div>
										<div class="form-group row connectHP" style="display: none;">
											<label class="col-md-4 col-form-label" style="text-align: right;">Bank:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBank" disabled>
											</div>
										</div>
										<div class="form-group row connectHP connectInHouse" style="display: none;">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment (%):</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPaymentPercent" disabled>
											</div>
										</div>
										<div class="form-group row connectHP connectInHouse" style="display: none;">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Term (Month):</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPaymentTerm" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtVehiclePrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Commercial Tax:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCommercialTax" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Retail Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRetailPrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Registration Tax & Fees:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRTADTax" value="0" style="text-align:right;" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Total Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTotalPrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row promotionPanel" style="display: none;">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Discount:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionDiscount" value="0" style="text-align:right;" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Selling Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtSellingPrice" value="0" disabled style="text-align:right;">
											</div>
										</div> 
									</div>
								</div>
								<!-- Calculation -->
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var OCNO = '<?= $oc_no ?>';
	$(function(){
		$("body").addClass("sidebar-collapse");
		if(OCNO){
			getOneRow();
		}
	});

	function getOneRow(){
		$.ajax({
			url: APP_URL + "api/sales/sales/get_sales_detail_info.php",
			type: "POST",
			data: JSON.stringify({ oc_no: OCNO })
		}).done(function(data) {	
			$("#txtOCNo").text(data.oc_no);

			if(data.broker_registration_no){
				$(".brokerInfoPanel").css("display", "");
				$("#txtBrokerRegistrationNo").val(data.broker_registration_no);
				$("#txtBrokerName").val(data.broker_name);
			}

			$("#txtCustomerRegistrationNo").val(data.customer_registration_no);
			$("#txtCustomerName").val(data.customer_name);
			$("#txtCustomerType").val(data.customer_type);
			$("#txtCustomerNRCNo").val(data.nrc_no);
			$("#txtCustomerMobileNo").val(data.mobile_no);
			$("#txtCustomerEmail").val(data.email);
			$("#txtCustomerTownship").val(data.township);

			if(data.customer_type=="B2B"){
				$("#txtCompanyName").val(data.company_name);
				$("#txtCompanyRegisterNo").val(data.company_register_no);
			}

			if(data.same_as_buyer==1){
				$("#chkSameAsBuyer").parent().removeClass("off");
			}
			$("#txtRTADName").val(data.rtad_name);
			$("#txtRTADNRCNo").val(data.rtad_nrc_no);
			$("#txtRTADMobileNo").val(data.rtad_mobile_no);
			$("#txtRTADTownship").val(data.rtad_township);

			$("#txtBrand").val(data.brand);
			$("#txtModel").val(data.model);
			$("#txtModelYear").val(data.model_year);
			$("#txtGrade").val(data.grade);
			$("#txtExteriorColor").val(data.exterior_color);
			$("#txtInteriorColor").val(data.interior_color);
			$("#txtVinNo").val(data.vin_no);
			$("#txtEngineNo").val(data.engine_no);

			$("#txtSalesDate").val(data.date);
			$("#txtSalesCenter").val(data.sales_center);

			if(data.payment_type=="HP"){
				$(".depositPanel").css("display", "");
				$("#txtDeposit").val(data.deposit);
			}

			$("#txtPaymentType").val(data.payment_type);

			if(data.payment_type=="HP"){
				$(".connectHP").css("display", "");
				$("#txtBank").val(data.bank);
			}else if(data.payment_type=="InHouse"){
				$(".connectInHouse").css("display", "");
			}
			$("#txtPaymentPercent").val(data.payment_percent);
			$("#txtPaymentTerm").val(data.payment_term);

			if(data.promotion_code!=""){
				$("#promotionPanel").css("display", "block");
				$("#txtPromotionCode").val(data.promotion_code);
				$("#txtPromotionDiscount").val(data.promotion_discount);
			}
			$("#txtVehiclePrice").val(data.vehicle_price);
			$("#txtCommercialTax").val(data.commercial_tax);
			$("#txtRetailPrice").val(data.retail_price);
			$("#txtRTADTax").val(data.rtad_tax);
			$("#txtTotalPrice").val(data.total_price);
			$("#txtSellingPrice").val(data.selling_price);
		});
	}
</script>
